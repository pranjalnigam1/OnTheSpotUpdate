import React from 'react'
import {login, logout} from "../state/slice/userSlice"
import { useDispatch,useSelector } from 'react-redux'




export const Login = () => {
  // const [newUsername, setNewUsername] = useState("");
  const dispatch = useDispatch();
  const username = useSelector((state) => state.user.value.username);

  const handleInputChange = (event) => {
    dispatch(login({ username: event.target.value }));
  };

  return (
    <div>
      <h1>{username}</h1>A
      <input onChange={handleInputChange} />
      <button onClick={() => dispatch(logout())}>LOGOUT</button>
    </div>
  );
};


