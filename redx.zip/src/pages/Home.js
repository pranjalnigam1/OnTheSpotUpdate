
import React, { useEffect } from 'react'
import { useSelector } from 'react-redux'

export const Home = () => {
  const username = useSelector((state) => 
  state.user.value.username);
  
  useEffect(() => {
    console.log(username)
  }, [username])

  return <h1>{username}</h1>;
};
